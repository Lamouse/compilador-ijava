#ifndef _LJPARSER_
#define _LJPARSER_

#include "structures.h"
#include "fillers.h"
#include "printers.h"
#include "symbols.h"
#include "semantic.h"
#include "clean.h"

#endif
